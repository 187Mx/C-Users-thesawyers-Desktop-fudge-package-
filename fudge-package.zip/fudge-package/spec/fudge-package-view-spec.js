'use babel';

import FudgePackageView from '../lib/fudge-package-view';

describe('FudgePackageView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
